package day1;

public class Datatypes {
	
	static int a=14;
	public static void main(String[] args) {
		int a=25;
		double b=3.2225;
		char c='z';
		boolean temp=true;
		String s="Example";
		sample();

	}
	public static void sample()
	{
		System.out.print(a);		
	}
}
