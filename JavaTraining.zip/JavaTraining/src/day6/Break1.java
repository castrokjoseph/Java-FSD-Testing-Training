package day6;

public class Break1 {

	public static void main(String[] args) {
		for(int i=1;i<=10;i++){  
	        if(i==5){  
	            //breaking the loop  
	            break;  
	        }  
	        System.out.println(i);  
	    }  
	    System.out.println("End of the program");

	}

}
