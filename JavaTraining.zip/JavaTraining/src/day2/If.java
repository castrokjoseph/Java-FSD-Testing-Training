package day2;

public class If {

	public static void main(String[] args) {
	
		int a=22,b=20;
		if(a==b){
			System.out.println("a is equal to b");
		}
		else
		{
			System.out.println("a is not equal to b");
		}
		System.out.println("end of the program");

	}

}
