package day2;

public class Ternary {

	public static void main(String[] args) {
		System.out.print(2>1||4>3?false:true);

	}

}
