package day2;

public class DoWhile {

	public static void main(String[] args) {
		int i=1;
		do
		{
			System.out.print(i+"");
			i++;
		}while(i<=10);
		
		 i=10;
		 do {
			 System.out.print(i+"");
			 i--;
			 
		 }while(i>=1);
		

	}

}
