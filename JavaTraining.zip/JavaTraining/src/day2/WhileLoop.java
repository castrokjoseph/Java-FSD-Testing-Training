package day2;

public class WhileLoop {

	public static void main(String[] args) {
		int i=1;
		while(i<=10)
		{
			System.out.println(i+" ");
			i++;
			//System.out.println("");
		}
		i=10;
		while(i>=1)
		{
			System.out.println(i+" ");
			i--;
		}
		
	}

}
