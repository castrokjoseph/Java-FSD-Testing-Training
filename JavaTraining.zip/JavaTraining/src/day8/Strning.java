package day8;

public class Strning {

	public static void main(String[] args) {
		String s1="sachin tendulkar";
		String s="BUGGATI";
		String a="volva";
		System.out.println(s1.substring(6));
		System.out.println(s1.substring(0, 6));
		System.out.println(s.toLowerCase());
		System.out.println(a.toUpperCase());
		System.out.println(s1.charAt(7));
		String c="hai"+"wolrd";
		System.out.println(c);
		String e="Elon";
		String M="Musk";
		String S4=e.concat(M);
		System.out.println(S4);
	}

}
